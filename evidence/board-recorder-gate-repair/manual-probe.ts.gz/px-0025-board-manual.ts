import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { SqliteDatabaseAdapter } from '/mnt/data/code/parallix-px-0025/src/adapters/sqlite/database-adapter.ts';
import { SqliteMigrationRunner, loadDefaultMigrations } from '/mnt/data/code/parallix-px-0025/src/adapters/sqlite/migration-runner.ts';
import { SqliteBoardLaneEventRepository } from '/mnt/data/code/parallix-px-0025/src/adapters/sqlite/board-lane-event-repository.ts';
import { BoardEventRecorder } from '/mnt/data/code/parallix-px-0025/src/application/recording/board-event-recorder.ts';
async function main() {
  const observations = [];
  const fixture = await import("/mnt/data/code/parallix-px-0025/test/fixtures/migrated-database.ts");
  await fixture.prepareMigratedSchema();
  for (let i = 0; i < 3; i++) {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'px-0025-board-probe-'));
    const db = new SqliteDatabaseAdapter();
    const cpu = () => { const v = process.cpuUsage(); return v.user + v.system; };
    try {
      fixture.copyMigratedSchema(path.join(dir, 'db.sqlite'));
      await db.open({ path: path.join(dir, 'db.sqlite') });
      const start = cpu();
      const before = await db.query("SELECT * FROM board_lane_events");
      if (before.length !== 0) throw new Error("fixture contaminated");
      const migrated = cpu();
      const repo = new SqliteBoardLaneEventRepository(db);
      const recorder = new BoardEventRecorder(repo);
      const wrote = await recorder.append({repositoryId: '/disposable', missionId: 'px-probe', from: 'backlog', to: 'active', trigger: 'activate', agent: 'codex', occurredAt: '2026-11-02T12:00:00Z', idempotencyKey: 'probe'} as any);
      const rows = await repo.findByMissionId('px-probe');
      const end = cpu();
      if (!wrote || rows.length !== 1 || rows[0].toStatus !== 'active') throw new Error('persistence failed');
      await db.close();
      await db.open({ path: path.join(dir, 'db.sqlite') });
      const reopened = await repo.findByMissionId('px-probe');
      if (reopened.length !== 1) throw new Error("row lost on reopen");
      observations.push({emptyBeforeWrite: true, wrote, rowsAfterReopen: reopened.length, recordAndReadCpuUs: end - migrated});
    } finally { await db.close(); fs.rmSync(dir, {recursive: true, force: true}); }
  }
  console.log(JSON.stringify(observations));
}
main();
