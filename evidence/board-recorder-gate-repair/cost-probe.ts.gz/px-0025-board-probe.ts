import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { SqliteDatabaseAdapter } from '/mnt/data/code/parallix-px-0025/src/adapters/sqlite/database-adapter.ts';
import { SqliteMigrationRunner, loadDefaultMigrations } from '/mnt/data/code/parallix-px-0025/src/adapters/sqlite/migration-runner.ts';
import { SqliteBoardLaneEventRepository } from '/mnt/data/code/parallix-px-0025/src/adapters/sqlite/board-lane-event-repository.ts';
import { BoardEventRecorder } from '/mnt/data/code/parallix-px-0025/src/application/recording/board-event-recorder.ts';
async function main() {
  const observations = [];
  for (let i = 0; i < 3; i++) {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'px-0025-board-probe-'));
    const db = new SqliteDatabaseAdapter();
    const cpu = () => { const v = process.cpuUsage(); return v.user + v.system; };
    try {
      await db.open({ path: path.join(dir, 'db.sqlite') });
      const start = cpu();
      await new SqliteMigrationRunner(db).applyPending(loadDefaultMigrations());
      const migrated = cpu();
      const repo = new SqliteBoardLaneEventRepository(db);
      const recorder = new BoardEventRecorder(repo);
      const wrote = await recorder.append({repositoryId: '/disposable', missionId: 'px-probe', from: 'backlog', to: 'active', trigger: 'activate', agent: 'codex', occurredAt: '2026-11-02T12:00:00Z', idempotencyKey: 'probe'} as any);
      const rows = await repo.findByMissionId('px-probe');
      const end = cpu();
      if (!wrote || rows.length !== 1 || rows[0].toStatus !== 'active') throw new Error('persistence failed');
      observations.push({migrationCpuUs: migrated - start, recordAndReadCpuUs: end - migrated});
    } finally { await db.close(); fs.rmSync(dir, {recursive: true, force: true}); }
  }
  console.log(JSON.stringify(observations));
}
main();
